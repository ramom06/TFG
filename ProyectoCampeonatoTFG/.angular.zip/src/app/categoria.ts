export interface Categoria {

}
