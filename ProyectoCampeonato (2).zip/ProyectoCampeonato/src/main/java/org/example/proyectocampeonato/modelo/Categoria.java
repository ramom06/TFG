package org.example.proyectocampeonato.modelo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(name = "categoria")
public class Categoria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_categoria;

    @Column(name = "nombre", nullable = false)
    private String nombre;

    @Column(nullable = false)
    private String modalidad;

    @Column(nullable = false)
    private String genero;

    @Column(name = "peso_minimo")
    @Min(value = 0, message = "{categoria.peso.minimo}")
    private Double pesoMinimo;

    @Min(value = 0, message = "{categoria.peso.minimo}")
    @Column(name = "peso_maximo")
    private Double pesoMaximo;

    @Column(name = "edad_maxima", nullable = false)
    @Min(value = 0, message = "{categoria.edadMaxima.minimo}")
    @Max(value = 100, message = "{categoria.edadMaxima.maximo}")
    private int edadMaxima;

    @Column(name = "edad_minima", nullable = false)
    @Min(value = 0, message = "{categoria.edadMinima.minimo}")
    @Max(value = 71, message = "{categoria.edadMaxima.maximo}")
    private int edadMinima;

    @OneToMany(mappedBy = "categoria", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private Set<Campeonato_Categoria> campeonatoCategorias = new HashSet<>();

    @OneToMany(mappedBy = "categoria", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private Set<Inscripcion> inscripciones = new HashSet<>();
}
