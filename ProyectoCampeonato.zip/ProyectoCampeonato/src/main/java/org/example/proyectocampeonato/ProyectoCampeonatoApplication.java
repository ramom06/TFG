package org.example.proyectocampeonato;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoCampeonatoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProyectoCampeonatoApplication.class, args);
    }

}
