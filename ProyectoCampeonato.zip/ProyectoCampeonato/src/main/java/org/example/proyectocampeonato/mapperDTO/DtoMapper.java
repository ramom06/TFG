package org.example.proyectocampeonato.mapperDTO;

import org.example.proyectocampeonato.dto.*;
import org.example.proyectocampeonato.modelo.*;
import org.springframework.stereotype.Component;

@Component
public class DtoMapper {

    // ── USUARIO ──────────────────────────────────────────────────────────────

    public UsuarioDTO toUsuarioDTO(Usuario u) {
        return UsuarioDTO.builder()
                .username(u.getNombre())
                .email(u.getEmail())
                // password nunca se mapea hacia el DTO de salida
                .rol(u.getRol())
                .build();
    }

    public Usuario toUsuarioEntity(UsuarioDTO dto) {
        return Usuario.builder()
                .nombre(dto.getUsername())
                .email(dto.getEmail())
                .password(dto.getPassword())
                .rol(dto.getRol())
                .build();
    }

    // ── ARBITRO ──────────────────────────────────────────────────────────────

    public ArbitroDTO toArbitroDTO(Arbitro a) {
        return ArbitroDTO.builder()
                .id_usuario(a.getId_usuario())
                .nombre(a.getNombre())
                .apellidos(a.getApellidos())
                .email(a.getEmail())
                .rol(a.getRol())
                .fechaRegistro(a.getFechaRegistro())
                .licencia(a.getLicencia())
                .categoriaArbitral(a.getCategoriaArbitral())
                .fechaNacimiento(a.getFechaNacimiento())
                .build();
    }

    public Arbitro toArbitroEntity(ArbitroDTO dto) {
        return Arbitro.builder()
                .nombre(dto.getNombre())
                .email(dto.getEmail())
                .password(dto.getPassword())
                .apellidos(dto.getApellidos())
                .rol(dto.getRol())
                .fechaNacimiento(dto.getFechaNacimiento())
                .licencia(dto.getLicencia())
                .categoriaArbitral(dto.getCategoriaArbitral())
                .build();
    }

    // ── CAMPEONATO ───────────────────────────────────────────────────────────

    public CampeonatoDTO toCampeonatoDTO(Campeonato c) {
        return CampeonatoDTO.builder()
                .nombre(c.getNombre())
                .fechaInicio(c.getFechaInicio())
                .fechaFin(c.getFechaFin())
                .ubicacion(c.getUbicacion())
                .estado(c.getEstado())
                .nivel(c.getNivel())
                .descripcion(c.getDescripcion())
                .urlPortada(c.getUrlPortada())
                .build();
    }

    public Campeonato toCampeonatoEntity(CampeonatoDTO dto) {
        return Campeonato.builder()
                .nombre(dto.getNombre())
                .fechaInicio(dto.getFechaInicio())
                .fechaFin(dto.getFechaFin())
                .ubicacion(dto.getUbicacion())
                .estado(dto.getEstado())
                .nivel(dto.getNivel())
                .descripcion(dto.getDescripcion())
                .urlPortada(dto.getUrlPortada())
                .build();
    }

    // ── CATEGORIA ────────────────────────────────────────────────────────────

    public CategoriaDTO toCategoriaDTO(Categoria c) {
        return CategoriaDTO.builder()
                .nombre(c.getNombre())
                .modalidad(c.getModalidad())
                .genero(c.getGenero())
                .pesoMinimo(c.getPesoMinimo())
                .pesoMaximo(c.getPesoMaximo())
                .edadMinima(c.getEdadMinima())
                .edadMaxima(c.getEdadMaxima())
                .build();
    }

    public Categoria toCategoriaEntity(CategoriaDTO dto) {
        return Categoria.builder()
                .nombre(dto.getNombre())
                .modalidad(dto.getModalidad())
                .genero(dto.getGenero())
                .pesoMinimo(dto.getPesoMinimo())
                .pesoMaximo(dto.getPesoMaximo())
                .edadMinima(dto.getEdadMinima())
                .edadMaxima(dto.getEdadMaxima())
                .build();
    }

    // ── COMPETIDOR ───────────────────────────────────────────────────────────

    public CompetidorDTO toCompetidorDTO(Competidor c) {
        // Usuario.fechaNacimiento es Date; CompetidorDTO usa LocalDate
        java.time.LocalDate fechaNac = null;
        if (c.getFechaNacimiento() != null) {
            fechaNac = c.getFechaNacimiento().toInstant()
                    .atZone(java.time.ZoneId.systemDefault())
                    .toLocalDate();
        }
        return CompetidorDTO.builder()
                .nombre(c.getNombre())
                .apellidos(c.getApellidos())
                .dni(c.getDni())
                .fechaNacimiento(fechaNac)
                .genero(c.getGenero())
                .club(c.getClub())
                .federacionAutonomica(c.getFederacionAutonomica())
                .build();
    }

    public Competidor toCompetidorEntity(CompetidorDTO dto) {
        // CompetidorDTO.fechaNacimiento es LocalDate; Usuario espera Date
        java.util.Date fechaNac = null;
        if (dto.getFechaNacimiento() != null) {
            fechaNac = java.util.Date.from(
                    dto.getFechaNacimiento()
                            .atStartOfDay(java.time.ZoneId.systemDefault())
                            .toInstant()
            );
        }
        return Competidor.builder()
                .nombre(dto.getNombre())
                .apellidos(dto.getApellidos())
                .dni(dto.getDni())
                .fechaNacimiento(fechaNac)
                .genero(dto.getGenero())
                .club(dto.getClub())
                .federacionAutonomica(dto.getFederacionAutonomica())
                .build();
    }

    // ── INSCRIPCION ──────────────────────────────────────────────────────────

    public InscripcionDTO toInscripcionDTO(Inscripcion i) {
        return InscripcionDTO.builder()
                .idCampeonato(i.getCampeonato().getId_campeonato())
                .idCategoria(i.getCategoria().getId_categoria())
                .idCompetidor(i.getCompetidor().getId_usuario())
                .nombreCampeonato(i.getCampeonato().getNombre())
                .nombreCategoria(i.getCategoria().getNombre())
                .nombreCompetidor(i.getCompetidor().getNombre() + " " + i.getCompetidor().getApellidos())
                .clubCompetidor(i.getCompetidor().getClub())
                .build();
    }

    // ── COMBATE ──────────────────────────────────────────────────────────────

    public CombateDTO toCombateDTO(Combate c) {
        CombateDTO.CombateDTOBuilder builder = CombateDTO.builder()
                .numeroTatami(c.getId().getNumeroTatami())
                .ronda(c.getRonda())
                .puntuacionRojo(c.getPuntuacionRojo())
                .puntuacionAzul(c.getPuntuacionAzul())
                .senshu(c.getSenshu())
                .estado(c.getEstado())
                .duracionSegundos(c.getDuracionSegundos())
                .observaciones(c.getObservaciones())
                .nombreCompetidorRojo(
                        c.getCompetidorRojo().getNombre() + " " + c.getCompetidorRojo().getApellidos()
                );

        // horaProgramada: LocalTime → Date
        if (c.getHoraProgramada() != null) {
            java.util.Date hp = java.util.Date.from(
                    c.getHoraProgramada()
                            .atDate(java.time.LocalDate.now())
                            .atZone(java.time.ZoneId.systemDefault())
                            .toInstant()
            );
            builder.horaProgramada(hp);
        }

        // horaInicioReal: LocalDateTime → Date
        if (c.getHoraInicioReal() != null) {
            java.util.Date hir = java.util.Date.from(
                    c.getHoraInicioReal()
                            .atZone(java.time.ZoneId.systemDefault())
                            .toInstant()
            );
            builder.horaInicioReal(hir);
        }

        // Competidor azul es nullable (bye)
        if (c.getCompetidorAzul() != null) {
            builder.idCompetidorAzul(c.getCompetidorAzul().getId_usuario())
                    .nombreCompetidorAzul(
                            c.getCompetidorAzul().getNombre() + " " + c.getCompetidorAzul().getApellidos()
                    );
        }

        return builder.build();
    }

    // ── CAMPEONATO_CATEGORIA ─────────────────────────────────────────────────

    public Campeonato_CategoriaDTO toCampeonatoCategoriaDTO(Campeonato_Categoria cc) {
        return Campeonato_CategoriaDTO.builder()
                .idCampeonato(cc.getCampeonato().getId_campeonato())
                .idCategoria(cc.getCategoria().getId_categoria())
                .modalidad(cc.getCategoria().getModalidad())
                .genero(cc.getCategoria().getGenero())
                .build();
    }

    // ── CLASIFICACION ────────────────────────────────────────────────────────

    public ClasificacionDTO toClasificacionDTO(Clasificacion cl) {
        return ClasificacionDTO.builder()
                .nombreCategoria(cl.getNombreCategoria())
                .nombreCompetidor(cl.getNombreCompetidor())
                .puntos(cl.getPuntos())
                .build();
    }
}