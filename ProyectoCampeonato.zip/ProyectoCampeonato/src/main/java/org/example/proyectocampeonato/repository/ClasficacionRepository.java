package org.example.proyectocampeonato.repository;

import org.example.proyectocampeonato.modelo.Clasificacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClasficacionRepository extends JpaRepository<Clasificacion, Integer> {
}
