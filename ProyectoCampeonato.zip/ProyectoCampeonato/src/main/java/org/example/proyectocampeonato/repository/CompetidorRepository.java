package org.example.proyectocampeonato.repository;

import org.example.proyectocampeonato.modelo.Competidor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompetidorRepository extends JpaRepository<Competidor, Integer> {
}
